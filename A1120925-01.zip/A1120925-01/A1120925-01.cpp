﻿// A1120925-01.cpp : 此檔案包含 'main' 函式。程式會於該處開始執行及結束執行。
//

#include <iostream>
using namespace std;


void PrintArray(int list[], int n)
{
    for (int i = 0; i < n; i++)
        cout << list[i] << " ";
    cout << endl;
}

void ArrayCopy(int dest[], int src[], int n)
{
    for (int i = 0; i < n; i++)
        dest[i] = src[i];
}

void ArrayInsert(int list[], int n, int value, int i)
{
    for (int index = n - 1; index > i; index--)
        list[index] = list[index - 1];
    list[i] = value;
}

void ArrayDelete(int list[], int n, int i)
{
    for (int index = 1; index < n - 1; index++)
        list[index] = list[index + 1];
    list[n - 1] = 0;
}

void PrintMatrix(int A[][4], int m, int n)
{
    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j < n; j++)
            cout << A[i][j] << " ";
        cout << endl;
    }
}

void PrintMatrix3(int A[][3], int m, int n)
{
    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j < n; j++)
            cout << A[i][j] << " ";
        cout << endl;
    }
}

void AddMatrix(int A[][3], int B[][3], int C[][3], int m, int n)
{
    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j < n; j++) 
        {
            C[i][j] = A[i][j] + B[i][j];
        }
    }
}


template< typename T, size_t M, size_t N >
void printarray(T(&theArray)[M][N]) {
    for (int y = 0; y < M; y++)
    {
        for (int x = 0; x < N; x++)
            cout << theArray[y][x] << " ";
        cout << endl;
    }
}

template< typename T, size_t M, size_t N >
void addmatrix(T(&A)[M][N], T(&B)[M][N], T(&C)[M][N]) 
{
    for (int i = 0; i < M; i++)
    {
        for (int j = 0; j < N; j++)
        {
            C[i][j] = A[i][j] + B[i][j];
        }
    }
}

template< typename T, size_t M, size_t N, size_t O >
void multiplymatrix(T(&A)[M][N], T(&B)[N][O], T(&C)[M][O])
{
    for (int i = 0; i < M; i++)
    {
        for (int j = 0; j < O; j++)
        {
            C[i][j] = 0;
            for (int k = 0; k < N; k++)
            {
                C[i][j] = C[i][j] + A[i][k] * B[k][j];
            }
        }
    }
}

int A[3][4] = { {1,2,3,4},{5,6,7,8},{9,10,11,12} };
float B[3][4] = { {1,2,3,4},{5,6,7,8},{9,10,11,12} };

int A1[4][3] = { {1,2,3},{4,5,6},{7,8,9},{10,11,12 } };
int B1[4][3] = { {0,1,2},{3,4,5},{6,7,8},{9,10,11 } };
int C1[4][3] = { 0 };
int C2[4][3] = { 0 };

int A21[3][2] = { {1,2},{3,4},{5,6} };
int B21[2][4] = { {0,1,1,2},{4,0,-1,3} };
int C21[3][4] = { 0 };

int main()
{
    int list1[8] = { 5,25,11,26,39,18,120,50 };
    PrintArray(list1, 8);
    cout << endl;

    int list2[8] = { 0 };
    ArrayCopy(list2, list1, 8);
    PrintArray(list2, 8);
    cout << endl;

    ArrayInsert(list1, 8, 27, 3);
    PrintArray(list1, 8);
    cout << endl;

    ArrayDelete(list2, 8, 3);
    PrintArray(list2, 8);
    cout << endl;

    int arr1[3][4] = { {1,2,3,4},{5,6,7,8},{9,10,11,12} };
    for (int i = 0; i < 3; i++)
    {
        for (int j = 0; j < 4; j++)
            cout << arr1[i][j] << " ";
        cout << endl;
    }
    PrintMatrix(arr1, 3, 4);
    cout << endl;

    int B[3][4] = { {1,2,3,4},{5,6,7,8},{9,10,11,12} };
    printarray(B);
    cout << endl;

    AddMatrix(A1, B1, C1, 4, 3);
    PrintMatrix3(C1, 4, 3);
    printarray(C1);
    cout << endl;

    addmatrix(A1, B1, C2);
    printarray(C2);
    cout << endl;

    multiplymatrix(A21, B21, C21);
    printarray(C21);
    cout << endl;
}

// 執行程式: Ctrl + F5 或 [偵錯] > [啟動但不偵錯] 功能表
// 偵錯程式: F5 或 [偵錯] > [啟動偵錯] 功能表

// 開始使用的提示: 
//   1. 使用 [方案總管] 視窗，新增/管理檔案
//   2. 使用 [Team Explorer] 視窗，連線到原始檔控制
//   3. 使用 [輸出] 視窗，參閱組建輸出與其他訊息
//   4. 使用 [錯誤清單] 視窗，檢視錯誤
//   5. 前往 [專案] > [新增項目]，建立新的程式碼檔案，或是前往 [專案] > [新增現有項目]，將現有程式碼檔案新增至專案
//   6. 之後要再次開啟此專案時，請前往 [檔案] > [開啟] > [專案]，然後選取 .sln 檔案
